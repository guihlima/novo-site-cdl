# Câmara de Dirigentes Lojistas de Caxias Maranhão 
# https://cdlcaxias.org.br/

Repositório de Backup do Website da CDL Caxias
Utilitários:

* HTML5
* JavaScript
* CSS
* MySQL
* PHP

### Implementado uma API de Webmail para o envio e encaminhamento automatico de emails de contato.

* Banco de Dados privado para fins de Segurança

Webdesign: Leonardo Almeida de Araújo

Cargo: Gestão de TI interno

![cdl1](https://user-images.githubusercontent.com/37451620/80383149-988cb500-8879-11ea-9a00-8633eb8e3b0a.PNG)

![cdl2](https://user-images.githubusercontent.com/37451620/80383151-99bde200-8879-11ea-8850-089696cba07d.PNG)

![cdl3](https://user-images.githubusercontent.com/37451620/80383153-9a567880-8879-11ea-8379-397b0abd3d9c.PNG)
