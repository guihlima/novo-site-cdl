const btnClose = document.querySelector("#btn-close")
const btnFloat = document.querySelector("#btn-balao")

btnClose.addEventListener("click",()=>{
    btnFloat.classList.add("desactive")
})

