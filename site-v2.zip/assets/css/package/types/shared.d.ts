export interface CSSSelector extends String {}

export interface SwiperModule {
  name: string;
}
